from django.apps import AppConfig


class RbacConfig(AppConfig):
    name = 'rbac'
    verbose_name = '权限管理'