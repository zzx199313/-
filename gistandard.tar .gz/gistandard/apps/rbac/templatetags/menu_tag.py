# -*- coding: UTF-8 -*-
# __author__ : RobbieHan
# __data__  : 2017/10/25

from django import template
from django.utils.safestring import mark_safe


register = template.Library()

