from django.apps import AppConfig


class AdmConfig(AppConfig):
    name = 'adm'
    verbose_name = '行政'